# Find stone pair(s)

## 1. QuestionA

​	该问题为从一堆石头中，找到一对重量差值为d的石头。

​    定义函数如下：

​	输入:const std::vector<int> &stones 带有石头重量信息的数组。

​	输入:int d 要寻找石头对的重量差值。

   返回值：所找到的石头对在石头堆中的位置。

​	`std::pair<int, int> findStonePair(const std::vector<int> &stones, int d);`

   注：石头堆中的不同位置的石头有可能重量相同，对于问题A则只需找到一对即可。

## 2. QuestionB

​		时间复杂度为O(n),空间复杂度为O(n);

​        测试代码请看main.cpp

​        比较好的方式是随机产生大量数据样本，并制作相应结果集。在与其比较。

​        由于春节将近，此部分尚未完善。采用固定数据集测试。

## 3.QuestionC

​        测试代码请看main.cpp

​        比较好的方式是随机产生大量数据样本，并制作相应结果集。在与其比较。

​        由于春节将近，此部分尚未完善。采用固定数据集测试。
