/*
 * @Description:
 * @Author: yao.xie
 * @Date: 2023-01-19 16:39:05
 * @LastEditTime: 2023-01-19 16:39:05
 * @LastEditors: yao.xie
 */

#ifndef DEV_QUESTIONA_H
#define DEV_QUESTIONA_H

#include <vector>

namespace QuestionA
{
    int rabbitGoesHome(int m, int n, const std::vector<std::vector<int>> &grid);
};

#endif // DEV_QUESTIONA_H
