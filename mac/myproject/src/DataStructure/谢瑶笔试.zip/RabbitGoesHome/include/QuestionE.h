/*
 * @Description:
 * @Author: yao.xie
 * @Date: 2023-01-19 15:43:23
 * @LastEditTime: 2023-01-19 15:56:31
 * @LastEditors: yao.xie
 */

#ifndef DEV_QUESTIONE_H
#define DEV_QUESTIONE_H
#include <vector>
namespace QuestionE
{
    std::vector<std::vector<std::pair<int, int>>>
    rabbitGoesHome(int m, int n, const std::vector<std::vector<int>> &grid);
};

#endif
