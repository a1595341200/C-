/*
 * @Description:
 * @Author: yao.xie
 * @Date: 2023-01-19 16:39:15
 * @LastEditTime: 2023-01-19 16:39:15
 * @LastEditors: yao.xie
 */

#ifndef DEV_QUESTIONB_H
#define DEV_QUESTIONB_H
#include <vector>

namespace QuestionB
{
    int rabbitGoesHome(int m, int n, const std::vector<std::vector<int>> &grid);
};

#endif // DEV_QUESTIONB_H
