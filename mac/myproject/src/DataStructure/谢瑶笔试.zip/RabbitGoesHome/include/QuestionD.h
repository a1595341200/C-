/*
 * @Description:
 * @Author: yao.xie
 * @Date: 2023-01-19 16:39:22
 * @LastEditTime: 2023-01-19 16:39:23
 * @LastEditors: yao.xie
 */

#ifndef DEV_QUESTIOND_H
#define DEV_QUESTIOND_H
#include <vector>
namespace QuestionD
{
    std::vector<std::vector<std::pair<int, int>>> rabbitGoesHome(int m, int n, const std::vector<std::vector<int>> &grid);
};
#endif
